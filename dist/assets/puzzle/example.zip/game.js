const rows = 4;
const columns = 4;

Grid.init(rows, columns);

let tiles = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'empty'];

// (randomly) initialize the grid with all of the tile values
let nextState = Grid.currentState;

for (let y = 0; y < Grid.rows; y += 1) {
  for (let x = 0; x < Grid.columns; x += 1) {
    // choose a random value from the remaining tiles
    const randomIndex = Math.floor(Math.random() * tiles.length);

    // `splice` removes the value from the array, so it can't be used twice
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/splice
    nextState[x][y] = tiles.splice(randomIndex, 1)[0];
  }
}

// update the game state
Grid.update(nextState);

Grid.onPointDown(({ x, y }) => {
  console.debug(`clicked grid cell (${x}, ${y})`);

  const state = Grid.currentState;
  const neighbors = Grid.getNeighbors({ x, y });

  // check each neighboring cell
  for (let i = 0; i < neighbors.length; i += 1) {
    const neighbor = neighbors[i];

    if (state[neighbor.x][neighbor.y] === 'empty') {
      // if a neighboring cell is empty, swap it with the one that was clicked
      state[neighbor.x][neighbor.y] = state[x][y];
      state[x][y] = 'empty';

      // show the change
      Grid.update(state);

      // we don't need to check any of the other neighbors
      // once we've found an empty cell, so can break out of the loop
      break;
    }
  }

  if (hasWonGame()) {
    alert('Congratulations, a winner is you!');
  }

});


const hasWonGame = () => {
  const state = Grid.currentState;
  const tiles = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'empty'];

  // iterate through the rows/columns and expect the value of each cell to match
  // the ordered `tiles` list. we put the y loop first, so the grid
  // values can be checked like this:
  // [ 1][ 2][ 3][ 4]
  // [ 5][ 6][ 7][ 8]
  // [ 9][10][11][12]
  // [13][14][15][16]
  let index = 0;
  for (let y = 0; y < Grid.rows; y += 1) {
    for (let x = 0; x < Grid.columns; x += 1) {
      if (state[x][y] !== tiles[index]) {
        console.debug(`${tiles[index]} is not in the right position`);
        return false;
      }

      index += 1;
    }
  }

  return true;
};
