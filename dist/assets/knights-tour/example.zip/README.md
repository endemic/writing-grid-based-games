# gridjs

smol JS class to make grid-based browser games

### Examples

#### Minesweeper
![Screen Shot 2023-03-14 at 8 12 00 PM](https://user-images.githubusercontent.com/51476/225171172-fe97a77f-242f-47a3-a866-77194c1e3c26.png)

#### Snake

![Screen Shot 2023-03-14 at 8 14 16 PM](https://user-images.githubusercontent.com/51476/225171209-e445d63a-3c97-47ad-8414-72e43a7a39b7.png)

#### Tetris

![Screen Shot 2023-03-14 at 8 16 16 PM](https://user-images.githubusercontent.com/51476/225171242-b316529c-aa48-4396-95d4-55f2312c8786.png)
