const rows = 8;
const columns = 8;

Grid.init(rows, columns);

const newState = Grid.state;

// simple helper function to determine if a number is even or odd
const isEven = number => number % 2 === 0;

// make the grid look like a chessboard, with alternating white/black tiles
for (let y = 0; y < rows; y += 1) {
  for (let x = 0; x < columns; x += 1) {
    newState[x][y] = isEven(x + y) ? 'white' : 'black';
  }
}

Grid.state = newState;

let knight;

Grid.onPointDown(({ x, y }) => {
  console.debug(`clicked grid cell (${x}, ${y})`);

  const newState = Grid.state;

  // handle condition of first move
  if (!knight) {
    knight = {x, y};

    newState[knight.x][knight.y] = 'knight';
  }

  const allowedMoves = getAllowedMoves(knight);

  // if the clicked {x, y} coords are in the list of allowed moves...
  if (allowedMoves.find(move => x === move.x && y === move.y)) {
    // draw the current position as "visited"
    newState[knight.x][knight.y] = 'visited';

    // set the new knight position
    knight = {x, y};

    // draw on the grid
    newState[knight.x][knight.y] = 'knight';
  }

  Grid.state = newState;

  if (hasWonGame()) {
    delayedAlert('Congratulations!');
  }
});

const getAllowedMoves = (knight) => {
  const state = Grid.state;

  return [
    // above
    { x: knight.x - 1, y: knight.y - 2},
    { x: knight.x + 1, y: knight.y - 2},

    // left
    { x: knight.x - 2, y: knight.y - 1},
    { x: knight.x - 2, y: knight.y + 1},

    // right
    { x: knight.x + 2, y: knight.y - 1},
    { x: knight.x + 2, y: knight.y + 1},

    // below
    { x: knight.x - 1, y: knight.y + 2},
    { x: knight.x + 1, y: knight.y + 2},
  ]
  .filter(Grid.withinBounds)
  .filter(({x, y}) => state[x][y] !== 'visited'); // can't move to a visited space
};

const hasWonGame = () => {
  const state = Grid.state;

  for (let y = 0; y < Grid.rows; y += 1) {
    for (let x = 0; x < Grid.columns; x += 1) {
      if (state[x][y] !== 'visited' && state[x][y] !== 'knight') {
        return false;
      }
    }
  }

  // if we've made it here, then the entire grid has been visited
  return true;
};

const delayedAlert = message => {
  setTimeout(() => {
    alert(message);
  }, 0);
};
