const rows = 3;
const columns = 3;

Grid.init(rows, columns);

const delayedAlert = message => {
  setTimeout(() => {
    alert(message);
  }, 0);
};

let player = 'x';
let gameOver = false;

Grid.onPointDown(({ x, y }) => {
  if (gameOver) {
    // reset the game
    gameOver = false;
    player = 'x';
    Grid.fill('');
    return;
  }

  const nextState = Grid.currentState;

  // do nothing if a player clicks on a square that's already filled
  if (!Grid.isEmpty(nextState[x][y])) {
    return;
  }

  nextState[x][y] = player;

  Grid.update(nextState);

  const winPositions = [
    [{x: 0, y: 0}, {x: 1, y: 0}, {x: 2, y: 0}], // row 1
    [{x: 0, y: 1}, {x: 1, y: 1}, {x: 2, y: 1}], // row 2
    [{x: 0, y: 2}, {x: 1, y: 2}, {x: 2, y: 2}], // row 3
  
    [{x: 0, y: 0}, {x: 0, y: 1}, {x: 0, y: 2}], // column 1
    [{x: 1, y: 0}, {x: 1, y: 1}, {x: 1, y: 2}], // column 2
    [{x: 2, y: 0}, {x: 2, y: 1}, {x: 2, y: 2}], // column 3
  
    [{x: 0, y: 0}, {x: 1, y: 1}, {x: 2, y: 2}], // diagonal 1
    [{x: 0, y: 2}, {x: 1, y: 1}, {x: 2, y: 0}], // diagonal 2
  ];
  
  // check for a win
  for (const group of winPositions) {
    let wonGame = false;
  
    if (group.every(square => nextState[square.x][square.y] === player)) {
      wonGame = true;
    }
  
    if (wonGame) {
      delayedAlert(`Player "${player}" wins!`);
      
      gameOver = true;
    }
  }

  // start with the assumption that all squares have been used
  let tieGame = true;

  // loop over each x/y value
  for (let x = 0; x < columns; x += 1) {
    for (let y = 0; y < rows; y += 1) {
      // if we find any empty square, it means the game isn't over yet
      if (Grid.isEmpty(nextState[x][y])) {
        tieGame = false;
      }
    }
  }

  if (tieGame) {
    delayedAlert('Tie game!');

    gameOver = true;
  }

  // switch players
  if (player === 'x') {
    player = 'o';
  } else {
    player = 'x';
  }
});
